from libs.Constants import *

def FSPL(distance, wave_length):
    return (4 * PI * distance / wave_length) ** 2